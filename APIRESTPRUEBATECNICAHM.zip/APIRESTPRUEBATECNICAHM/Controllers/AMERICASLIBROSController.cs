﻿using APIRESTPRUEBATECNICAHM.Models.Repository;
using Microsoft.AspNetCore.Mvc;
using static APIRESTPRUEBATECNICAHM.Models.AMERICASLIBROS;
using System.Linq;
using APIRESTPRUEBATECNICAHM.Contexts;
using Microsoft.EntityFrameworkCore;

namespace APIRESTPRUEBATECNICAHM.Controllers
{
    public class AMERICASLIBROSController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        private IAMERICASLIBROSRepository _americasLibrosRepository;
        protected readonly Conexion _context;
        public AMERICASLIBROSController(Conexion context) => _context = context;

        public AMERICASLIBROSController(IAMERICASLIBROSRepository americasLibrosRepository)
        {
            _americasLibrosRepository = americasLibrosRepository;
        }

        [HttpGet("/autores")]
        [ActionName(nameof(GetAutoressAsync))]
        public IEnumerable<Autores> GetAutoressAsync()
        {
            return _americasLibrosRepository.GetAutores();
        }

        [HttpGet("/GetLibroByAutor")]
        public ActionResult<AutorConLibros> ObtenerAutorYLibros(int IdAutor)
        {
            Autores autor = _americasLibrosRepository.GetAutorById(IdAutor);
            if (autor == null)
            {
                return NotFound();
            }

            List<Libros> libros = _americasLibrosRepository.GetLibroByAutor(IdAutor);

            AutorConLibros autorConLibros = new AutorConLibros
            {
                Nombre = autor.Nombre,
                Apellido = autor.Apellido,
                Libros = libros
            };

            return autorConLibros;
        }

        [HttpGet("{IdAutor}/Autor")]
        [ActionName(nameof(GetAutorById))]
        public ActionResult<Autores> GetAutorById(int IdAutor)
        {
            var autorByID = _americasLibrosRepository.GetAutorById(IdAutor);
            if (autorByID == null)
            {
                return NotFound();
            }
            return autorByID;
        }

        [HttpGet("/libros")]
        [ActionName(nameof(GetLibrosAsync))]
        public IEnumerable<Libros> GetLibrosAsync()
        {
            return _americasLibrosRepository.GetLibros();
        }

        [HttpGet("{IdLibro}/Libro")]
        [ActionName(nameof(GetLibroById))]
        public ActionResult<Libros> GetLibroById(int IdLibro)
        {
            var libroByID = _americasLibrosRepository.GetLibroById(IdLibro);
            if (libroByID == null)
            {
                return NotFound();
            }
            return libroByID;
        }

        [HttpPost]
        [ActionName(nameof(CreateAutorAsync))]
        public async Task<ActionResult<Autores>> CreateAutorAsync(Autores autor)
        {
            await _americasLibrosRepository.CreateAutorAsync(autor);
            return CreatedAtAction(nameof(GetAutorById), new { id = autor.Id }, autor);
        }

        [HttpPut("UpdateAutor")]
        [ActionName(nameof(UpdateAutor))]
        public async Task<ActionResult> UpdateAutor(int id, Autores autor)
        {
            if (id != autor.Id)
            {
                return BadRequest();
            }

            await _americasLibrosRepository.UpdateAutorAsync(autor);

            return NoContent();

        }

        [HttpDelete("DeleteAutor")]
        [ActionName(nameof(DeleteAutor))]
        public async Task<IActionResult> DeleteAutor(int id)
        {
            var autor = _americasLibrosRepository.GetAutorById(id);
            if (autor == null)
            {
                return NotFound();
            }

            await _americasLibrosRepository.DeleteAutorAsync(autor);

            return NoContent();
        }

        [HttpPut("UpdateLibro")]
        [ActionName(nameof(UpdateAutor))]
        public async Task<ActionResult> UpdateLibro(int id, Libros libro)
        {
            if (id != libro.Id)
            {
                return BadRequest();
            }

            await _americasLibrosRepository.UpdateLibrosAsync(libro);

            return NoContent();

        }

        [HttpDelete("DeleteLibro")]
        [ActionName(nameof(DeleteLibro))]
        public async Task<IActionResult> DeleteLibro(int id)
        {
            var libros = _americasLibrosRepository.GetLibroById(id);
            if (libros == null)
            {
                return NotFound();
            }

            await _americasLibrosRepository.DeleteLibroAsync(libros);

            return NoContent();
        }

        [HttpGet]
        [Route("librosFilter")]
        public async Task<IActionResult> ObtenerLibros(int? autor = null, DateTime? fechaInicio = null, DateTime? fechaFin = null)
        {
            var libros = await _context.Libros.ToListAsync();

            if (fechaInicio.HasValue || fechaFin.HasValue)
            {
                libros = _americasLibrosRepository.FiltrarLibrosPorAutorYFecha(libros, autor, fechaInicio.GetValueOrDefault(DateTime.MinValue), fechaFin.GetValueOrDefault(DateTime.MaxValue)).ToList();
            }

            return View(libros);
        }

        public class AutorConLibros
        {
            public string Nombre { get; set; }
            public string Apellido { get; set; }
            public List<Libros> Libros { get; set; }
        }
    }
}
