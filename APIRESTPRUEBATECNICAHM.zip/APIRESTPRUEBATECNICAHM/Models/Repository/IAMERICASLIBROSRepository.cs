﻿using DocumentFormat.OpenXml.Bibliography;
using static APIRESTPRUEBATECNICAHM.Models.AMERICASLIBROS;

namespace APIRESTPRUEBATECNICAHM.Models.Repository
{
    public interface IAMERICASLIBROSRepository
    {
        Task<Autores> CreateAutorAsync(Autores autor);
        Task<bool> DeleteAutorAsync(Autores autor);
        Autores GetAutorById(int Id);
        IEnumerable<Autores> GetAutores();
        Task<bool> UpdateAutorAsync(Autores autor);

        Task<Libros> CreateLibroAsync(Libros libros);
        Task<bool> DeleteLibroAsync(Libros libros);
        Libros GetLibroById(int Id);
        List<Libros> GetLibroByAutor(int IdAutor);
        IEnumerable<Libros> GetLibros();
        Task<bool> UpdateLibrosAsync(Libros libros);
        IEnumerable<Libros> FiltrarLibrosPorAutorYFecha(IEnumerable<Libros> libros, int? autor, DateTime fechaInicio, DateTime fechaFin);
    }
}
