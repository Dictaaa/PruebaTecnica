﻿using APIRESTPRUEBATECNICAHM.Contexts;
using Microsoft.EntityFrameworkCore;
using static APIRESTPRUEBATECNICAHM.Models.AMERICASLIBROS;

namespace APIRESTPRUEBATECNICAHM.Models.Repository
{
    public class AMERICASLIBROSRepository : IAMERICASLIBROSRepository
    {

        protected readonly Conexion _context;
        public AMERICASLIBROSRepository(Conexion context) => _context = context;

        public IEnumerable<Autores> GetAutores()
        {
            return _context.Autores.ToList();
        }

        public Autores GetAutorById(int IdAutor)
        {
            return _context.Autores.Find(IdAutor);
        }
        public async Task<Autores> CreateAutorAsync(Autores autor)
        {
            await _context.Set<Autores>().AddAsync(autor);
            await _context.SaveChangesAsync();
            return autor;
        }

        public async Task<bool> UpdateAutorAsync(Autores autor)
        {
            _context.Entry(autor).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAutorAsync(Autores autor)
        {
            //var entity = await GetByIdAsync(id);
            if (autor is null)
            {
                return false;
            }
            _context.Set<Autores>().Remove(autor);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<Libros> CreateLibroAsync(Libros libros)
        {
            await _context.Set<Libros>().AddAsync(libros);
            await _context.SaveChangesAsync();
            return libros;
        }

        public async Task<bool> DeleteLibroAsync(Libros libros)
        {
            //var entity = await GetByIdAsync(id);
            if (libros is null)
            {
                return false;
            }
            _context.Set<Libros>().Remove(libros);
            await _context.SaveChangesAsync();

            return true;
        }

        public Libros GetLibroById(int IdLibro)
        {
            return _context.Libros.Find(IdLibro);
        }

        public IEnumerable<Libros> GetLibros()
        {
            return _context.Libros.ToList();
        }

        public async Task<bool> UpdateLibrosAsync(Libros libros)
        {
            _context.Entry(libros).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return true;
        }

        //List<Libros> GetLibroByAutor(int IdAutor)
        //{
        //    return _context.Libros.Where(l => l.IdAutor == IdAutor).ToList();
        //}

        List<Libros> IAMERICASLIBROSRepository.GetLibroByAutor(int IdAutor)
        {
            return _context.Libros.Where(l => l.IdAutor == IdAutor).ToList();
        }


        IEnumerable<Libros> IAMERICASLIBROSRepository.FiltrarLibrosPorAutorYFecha(IEnumerable<Libros> libros, int? autor, DateTime fechaInicio, DateTime fechaFin)
        {
            libros = libros.Where(l => l.IdAutor == autor);

            libros = libros.Where(l => l.FechaInicio >= fechaInicio && l.FechaFin <= fechaFin);

            return libros;
        }
    }
}
