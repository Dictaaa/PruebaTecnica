﻿using System.ComponentModel.DataAnnotations;

namespace APIRESTPRUEBATECNICAHM.Models
{
    public class AMERICASLIBROS
    {
        public class Autores
        {
            [Key]
            public int Id { get; set; }
            public string Nombre { get; set; }
            public string Apellido { get; set; }
        }

        public class Libros
        {
            [Key]
            public int Id { get; set; }
            public string Titulo { get; set; }
            public int IdAutor { get; set; }
            public DateTime FechaInicio { get; set; }
            public DateTime FechaFin { get; set; }

        }
    }
}
