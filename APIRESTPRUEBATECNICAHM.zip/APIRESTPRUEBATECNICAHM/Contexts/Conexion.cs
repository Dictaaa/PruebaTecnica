﻿using APIRESTPRUEBATECNICAHM.Models;
using Microsoft.EntityFrameworkCore;
using static APIRESTPRUEBATECNICAHM.Models.AMERICASLIBROS;

namespace APIRESTPRUEBATECNICAHM.Contexts
{
    public class Conexion : DbContext
    {
        public Conexion(DbContextOptions<Conexion> options) : base(options)
        {

        }

        public DbSet<Autores> Autores { get; set; }
        public DbSet<Libros> Libros { get; set; }
    }
}
